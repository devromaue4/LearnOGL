#ifndef __SKELETON_H__
#define __SKELETON_H__
#if _MSC_VER > 1000
#	pragma once
#endif	// #if _MSC_VER > 1000

#include <string>
#include <fstream>

#include "MathLib/MathLib.h"

class Bone
{
public:
	Bone( const std::string& name, int id, int parentID )
		: m_Name(name)
		, m_ID(id)
		, m_ParentID(parentID)
		, m_Parent(NULL)
		, m_Next(NULL)
		, m_Child(NULL)
		, m_Transform(NULL)
	{}

	void LinkChildBone( Bone* bone )
	{
		Bone* oldChild = m_Child;
		m_Child = bone;
		m_Child->m_Next = oldChild;
		m_Child->m_Parent = this;
	}

	Bone* FindInChildrensByID( int ID )
	{
		if ( !m_Child )
			return NULL;

		Bone* child = m_Child;
		Bone* found = NULL;
		while ( child )
		{
			if ( child->GetID() == ID )
				return child;

			found = child->FindInChildrensByID( ID );
			if ( found )
				break;
			child = child->GetNext();
		}

		return found;
	}


	int GetID( void ) const
	{
		return m_ID;
	}
	int GetParentID( void ) const
	{
		return m_ParentID;
	}
	Bone* GetParent( void ) const
	{
		return m_Parent;
	}
	Bone* GetNext( void ) const
	{
		return m_Next;
	}
	Bone* GetChild( void ) const
	{
		return m_Child;
	}

	void SetBindPoseInv( const Transform& m )
	{
		m_BindPoseInv = m;
	}

	const Transform& GetBindPoseInv( void ) const
	{
		return m_BindPoseInv;
	}

	void SetTransform( Transform* transform )
	{
		m_Transform = transform;
	}

	Transform* GetTransform( void ) const
	{
		return m_Transform;
	}

	void AnimateHierarhy( const Transform* parentTransform )
	{
		if ( parentTransform )
		{
			(*m_Transform) = m_Transform->Mod( *parentTransform );
		}

		Bone* child = m_Child;
		while ( child )
		{
			child->AnimateHierarhy( m_Transform );
			child = child->GetNext();
		}

		(*m_Transform) = m_BindPoseInv.Mod2( *m_Transform );
	}

	void SetupBindPose( void )
	{
		if ( m_Transform )
			this->SetBindPoseInv( m_Transform->GetInverse() );

		Bone* child = m_Child;
		while ( child )
		{
			child->SetupBindPose();
			child = child->GetNext();
		}
	}

private:

	std::string		m_Name;
	int				m_ID;
	int				m_ParentID;
	Bone*			m_Parent;
	Bone*			m_Next;
	Bone*			m_Child;

	Transform*		m_Transform;
	Transform		m_BindPoseInv;
};



class Skeleton
{
public:
	Skeleton()
		: m_NumBones(0)
		, m_RootBone(NULL)
	{}

	void ReadFromStream( std::ifstream& stream )
	{
		stream >> m_NumBones;

		std::string name;
		int i, id, parentID;

		for ( i = 0; i < m_NumBones; ++i )
		{
			stream >> name >> id >> parentID;
			this->AddBone( new Bone( name, id, parentID ) );
		}
	}

	void AddBone( Bone* bone )
	{
		if ( !bone )
			return;

		if ( !m_RootBone )
		{
			m_RootBone = bone;
			return;
		}

		Bone* parent = this->GetBoneByID( bone->GetParentID() );
		if ( parent )
			parent->LinkChildBone( bone );
	}

	int GetNumBones( void ) const
	{
		return m_NumBones;
	}

	Bone* GetBoneByID( int ID )
	{
		if ( !m_RootBone )
			return NULL;
		if ( m_RootBone->GetID() == ID )
			return m_RootBone;

		return m_RootBone->FindInChildrensByID( ID );
	}

	void AnimateHierarhy( void )
	{
		if ( m_RootBone )
			m_RootBone->AnimateHierarhy( NULL );
	}

	void SetupBindPose( void )
	{
		if ( m_RootBone )
			m_RootBone->SetupBindPose();
	}

private:

	int			m_NumBones;
	Bone*		m_RootBone;
};

#endif	// __SKELETON_H__

