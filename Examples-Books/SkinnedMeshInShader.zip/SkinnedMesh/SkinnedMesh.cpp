#include "stdafx.h"



SkinnedMesh::SkinnedMesh()
	: m_NumVertexes(0)
	, m_NumIndexes(0)
	, m_Vertexes(NULL)
	, m_Indexes(NULL)
	, m_DrawVertexes(NULL)
	, m_BonesTransform(NULL)
	, m_AnimationTime(0.0f)
	, m_VertexBuffer(0)
	, m_IndexBuffer(0)
{}
SkinnedMesh::~SkinnedMesh()
{
	if ( m_Vertexes )
		delete [] m_Vertexes;
	if ( m_Indexes )
		delete [] m_Indexes;
	if ( m_DrawVertexes )
		delete [] m_DrawVertexes;
	if ( m_BonesTransform )
		delete [] m_BonesTransform;
}



void SkinnedMesh::ReadFromStream( std::ifstream& stream )
{
	int i, j;

	stream >> m_NumVertexes >> m_NumIndexes;

	m_Vertexes = new Vertex[m_NumVertexes];
	m_Indexes = new INDEX_TYPE[m_NumIndexes];
	m_DrawVertexes = new DrawVertex[m_NumVertexes];

	// iOrange - reading vertexes
	Vertex* v = m_Vertexes;
	DrawVertex* dv = m_DrawVertexes;
	for ( i = 0; i < m_NumVertexes; ++i, ++v, ++dv )
	{
		stream >> v->pos.x >> v->pos.y >> v->pos.z;				// position
		stream >> v->normal.x >> v->normal.y >> v->normal.z;	// normal
		stream >> dv->uv.x >> dv->uv.y;							// texCoord
		stream >> v->numWeights;								// num weights
		for ( j = 0; j < v->numWeights; ++j )
			stream >> v->weights[j].boneID >> v->weights[j].weigth;
	}

	// iOrange - now limit weights count to MAX_SHADER_WEIGHTS
	this->CutLimitWeights( MAX_SHADER_WEIGHTS );
	this->MoveWeightsToVertexes();

	// iOrange - reading indexes
	INDEX_TYPE* p = m_Indexes;
	for ( i = 0; i < m_NumIndexes; ++i )
		stream >> *p++;

	this->CreateVBO();
}

void SkinnedMesh::BindSkeleton( Skeleton* skeleton )
{
	if ( NULL != (m_Skeleton = skeleton) )
	{
		if ( m_BonesTransform )
			delete [] m_BonesTransform;

		m_BonesTransform = new Transform[m_Skeleton->GetNumBones()];

		Bone* bone;
		for ( int i = 0; i < m_Skeleton->GetNumBones(); ++i )
		{
			if ( bone = m_Skeleton->GetBoneByID( i ) )
				bone->SetTransform( m_BonesTransform + i );
		}
	}
}

void SkinnedMesh::BindAnimTrack( AnimTrack* animTrack )
{
	if ( !m_Skeleton || !animTrack )
		return;

	m_AnimTrack = animTrack;

	// iOrange - setup first frame up!
	this->UpdateAnimation( 0 );
	m_Skeleton->SetupBindPose();
}

void SkinnedMesh::UpdateAnimation( float deltaTime )
{
	if ( !m_Skeleton || !m_AnimTrack )
		return;

	const float fps  = 10.0f;

	m_AnimationTime += deltaTime;

	// =[ 0r@ngE ]= - calculating 2 current frames and lerp time between them
	float st        = m_AnimationTime * fps;
	int   ist       = (int)floorf( st );
	int   f0        = ist % m_AnimTrack->GetNumFrames();
	int   f1        = ( f0 + 1 ) % m_AnimTrack->GetNumFrames();
	float frameLerp = st - float( ist );
	int   i;

	AnimFrame* frame0 = m_AnimTrack->GetAnimFrame( f0 );
	AnimFrame* frame1 = m_AnimTrack->GetAnimFrame( f1 );

	for ( i = 0; i < m_Skeleton->GetNumBones(); ++i )
	{
		vec3 offset = lerp( frame0->GetOffset( i ), frame1->GetOffset( i ), frameLerp );
		quat rotation = slerp( frame0->GetRotation( i ), frame1->GetRotation( i ), frameLerp );

		m_BonesTransform[i].q = rotation.normalize();
		m_BonesTransform[i].v = offset;
	}

	m_Skeleton->AnimateHierarhy();
}

void SkinnedMesh::CreateVBO( void )
{
	glext::glGenBuffersARB( 1, &m_VertexBuffer );
	glext::glGenBuffersARB( 1, &m_IndexBuffer );

	glext::glBindBufferARB( GL_ARRAY_BUFFER, m_VertexBuffer );
	glext::glBufferDataARB( GL_ARRAY_BUFFER, m_NumVertexes * sizeof(DrawVertex), m_DrawVertexes, GL_STATIC_DRAW );

	glext::glBindBufferARB( GL_ELEMENT_ARRAY_BUFFER, m_IndexBuffer );
	glext::glBufferDataARB( GL_ELEMENT_ARRAY_BUFFER, m_NumIndexes * sizeof(INDEX_TYPE), m_Indexes, GL_STATIC_DRAW );

	glext::glBindBufferARB( GL_ARRAY_BUFFER, 0 );
	glext::glBindBufferARB( GL_ELEMENT_ARRAY_BUFFER, 0 );
}

void SkinnedMesh::Draw( int posAttrib, int uvAttrib, int indsAttrib, int weightsAttrib, int bonesArray ) const
{
	glext::glUniform1fvARB( bonesArray, m_Skeleton->GetNumBones() * 7, reinterpret_cast<const float *>(m_BonesTransform) );

	glext::glBindBufferARB( GL_ARRAY_BUFFER, m_VertexBuffer );
	glext::glBindBufferARB( GL_ELEMENT_ARRAY_BUFFER, m_IndexBuffer );

	glext::glEnableVertexAttribArrayARB( posAttrib );
	glext::glEnableVertexAttribArrayARB( indsAttrib );
	glext::glEnableVertexAttribArrayARB( weightsAttrib );
	glext::glEnableVertexAttribArrayARB( uvAttrib );

	glext::glVertexAttribPointerARB( posAttrib, 3, GL_FLOAT, GL_FALSE, sizeof(DrawVertex), NULL );
	glext::glVertexAttribPointerARB( indsAttrib, 4, GL_FLOAT, GL_FALSE, sizeof(DrawVertex), vbo_offsetof(DrawVertex, boneIDs) );
	glext::glVertexAttribPointerARB( weightsAttrib, 4, GL_FLOAT, GL_FALSE, sizeof(DrawVertex), vbo_offsetof(DrawVertex, weights) );
	glext::glVertexAttribPointerARB( uvAttrib, 2, GL_FLOAT, GL_FALSE, sizeof(DrawVertex), vbo_offsetof(DrawVertex, uv) );

	glDrawElements( GL_TRIANGLES, m_NumIndexes,
					sizeof(INDEX_TYPE) == 2 ? GL_UNSIGNED_SHORT : GL_UNSIGNED_INT,
					NULL );
}


static bool WeightComp( const VertexWeight& w1, const VertexWeight& w2 )
{
	return w1.weigth > w2.weigth;
}

void SkinnedMesh::CutLimitWeights( int limit )
{
	Vertex* vertexes = m_Vertexes;
	int i, j;
	float accumInv;

	for ( i = 0; i < m_NumVertexes; ++i, ++vertexes )
		if ( vertexes->numWeights > limit )
		{
			std::vector<VertexWeight>	weights( vertexes->numWeights );
			j = 0;
			for ( std::vector<VertexWeight>::iterator it = weights.begin(); it != weights.end(); ++it, ++j )
			{
				it->boneID = vertexes->weights[j].boneID;
				it->weigth = vertexes->weights[j].weigth;
			}
			std::sort( weights.begin(), weights.end(), WeightComp );
			accumInv = 0.0f;
			for ( j = 0; j < limit; ++j )
				accumInv += weights[j].weigth;
			accumInv = 1.0f / accumInv;
			for ( j = 0; j < limit; ++j )
			{
				vertexes->weights[j].boneID = weights[j].boneID;
				vertexes->weights[j].weigth = weights[j].weigth * accumInv;
			}
			vertexes->numWeights = limit;
		}
}

void SkinnedMesh::MoveWeightsToVertexes( void )
{
	Vertex* vertexes = m_Vertexes;
	DrawVertex* drawVertexes = m_DrawVertexes;
	int i, j;

	for ( i = 0; i < m_NumVertexes; ++i, ++vertexes, ++drawVertexes )
	{
		drawVertexes->pos = vertexes->pos;
		for ( j = 0; j < MAX_SHADER_WEIGHTS; ++j )
			if ( j >= vertexes->numWeights )
			{
				drawVertexes->boneIDs[j] = 0.0f;
				drawVertexes->weights[j] = 0.0f;
			}
			else
			{
				drawVertexes->boneIDs[j] = static_cast<float>(vertexes->weights[j].boneID);
				drawVertexes->weights[j] = vertexes->weights[j].weigth;
			}
	}
}

