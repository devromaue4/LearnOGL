#ifndef __TGA_H__
#define __TGA_H__
#if _MSC_VER > 1000
#	pragma once
#endif	// #if _MSC_VER > 1000

#pragma warning ( disable : 4996 )	// warning C4996: 'fopen': This function or variable may be unsafe. Consider using fopen_s instead.


typedef struct _TgaHeader
{
	uint8		id_length, colormap_type, image_type;
	uint16		colormap_index, colormap_length;
	uint8		colormap_size;
	uint16		x_origin, y_origin, width, height;
	uint8		pixel_size, attributes;
} TgaHeader;

static int LoadTGAFile( const char* name, int& width, int& height, int& bpp, byte** data )
{
	if ( name == NULL || data == NULL )
		return 0;

	FILE* file = fopen( name, "rb" );
	if ( NULL == file )
		return 0;

	int			i, columns, rows, row_inc, row, col;
	uint8		*buf_p, *buffer, *pixbuf, *targa_rgba;
	int			length, samples, readpixelcount, pixelcount;
	uint8		palette[256][4], red, green, blue, alpha;
	bool		compressed;
	TgaHeader	targa_header;

	fseek( file, 0, SEEK_END );
	length = ftell( file );
	fseek( file, 0, SEEK_SET );

	if ( 0 >= length )
		return 0;
	buffer = (uint8 *)malloc( length );
	if ( buffer == NULL )
		return 0;

	fread( buffer, 1, length, file );
	fclose( file );

	if ( !buffer )
		return 0;

	buf_p = buffer;
	targa_header.id_length     = *buf_p++;
	targa_header.colormap_type = *buf_p++;
	targa_header.image_type    = *buf_p++;

	targa_header.colormap_index = buf_p[0] + buf_p[1] * 256;
	buf_p += 2;
	targa_header.colormap_length = buf_p[0] + buf_p[1] * 256;
	buf_p += 2;
	targa_header.colormap_size = *buf_p++;
	targa_header.x_origin = ( *((short *)buf_p) );
	buf_p += 2;
	targa_header.y_origin = ( *((short *)buf_p) );
	buf_p += 2;
	targa_header.width    = ( *((short *)buf_p) );
	buf_p += 2;
	targa_header.height   = ( *((short *)buf_p) );
	buf_p += 2;
	targa_header.pixel_size = *buf_p++;
	targa_header.attributes = *buf_p++;
	if ( targa_header.id_length != 0 )
		buf_p += targa_header.id_length;

	bpp    = targa_header.pixel_size;
	height = targa_header.height;
	width  = targa_header.width;

	if ( targa_header.image_type == 1 || targa_header.image_type == 9 )
	{
		if ( targa_header.pixel_size != 8 )
		{
			free( buffer );
			return 0;
		}
		if ( targa_header.colormap_length != 256 )
		{
			free( buffer );
			return 0;
		}
		if ( targa_header.colormap_index )
		{
			free( buffer );
			return 0;
		}
		if ( targa_header.colormap_size == 24 )
		{
			for ( i=0; i<targa_header.colormap_length; i++ )
			{
				palette[i][0] = *buf_p++;
				palette[i][1] = *buf_p++;
				palette[i][2] = *buf_p++;
				palette[i][3] = 255;
			}
		}
		else if ( targa_header.colormap_size == 32 )
		{
			for ( i=0; i<targa_header.colormap_length; i++ )
			{
				palette[i][0] = *buf_p++;
				palette[i][1] = *buf_p++;
				palette[i][2] = *buf_p++;
				palette[i][3] = *buf_p++;
			}
		}
		else
		{
			free( buffer );
			return 0;
		}
	}
	else if ( targa_header.image_type == 2 || targa_header.image_type == 10 )
	{
		if ( targa_header.pixel_size != 32 && targa_header.pixel_size != 24 )
		{
			free( buffer );
			return 0;
		}
	}
	else if ( targa_header.image_type == 3 || targa_header.image_type == 11 )
	{
		if ( targa_header.pixel_size != 8 )
		{
			free( buffer );
			return 0;
		}
	}

	columns = targa_header.width;
	width   = columns;

	rows   = targa_header.height;
	height = rows;

	targa_rgba  = (uint8 *)malloc( columns * rows * 4 );
	uint8* pData = targa_rgba;
	if ( pData == NULL )
	{
		free( buffer );
		return 0;
	}

	if ( targa_header.attributes & 0x20 )
	{
		pixbuf = targa_rgba;
		row_inc = 0;
	}
	else 
	{
		pixbuf = targa_rgba + (rows - 1) * columns * 4;
		row_inc = -columns * 4 * 2;
	}

	compressed = ( targa_header.image_type == 9 || targa_header.image_type == 10 || targa_header.image_type == 11 );
	for ( row = col = 0, samples = 4; row < rows; )
	{
		pixelcount = 0x10000;
		readpixelcount = 0x10000;

		if ( compressed ) 
		{
			pixelcount = *buf_p++;
			if ( pixelcount & 0x80 )
				readpixelcount = 1;
			pixelcount = 1 + (pixelcount & 0x7f);
		}

		while( pixelcount-- && (row < rows) ) 
		{
			if ( readpixelcount-- > 0 ) 
			{
				switch( targa_header.image_type ) 
				{
					case 1:
					case 9:
						blue  = *buf_p++;
						red   = palette[blue][0];
						green = palette[blue][1];
						alpha = palette[blue][3];
						blue  = palette[blue][2];
						if ( alpha != 255 )
							samples = 4;
					break;
					case 2:
					case 10:
						samples = 4;
						blue  = *buf_p++;
						green = *buf_p++;
						red   = *buf_p++;
						alpha = 255;
						if ( targa_header.pixel_size == 32 )
							alpha = *buf_p++;
					break;
					case 3:
					case 11:
						blue  = green = red = *buf_p++;
						alpha = 255;
					break;
				}
			}

			*pixbuf++ = red;
			*pixbuf++ = green;
			*pixbuf++ = blue;
			*pixbuf++ = alpha;
			if ( ++col == columns ) 
			{
				row++;
				col = 0;
				pixbuf += row_inc;
			}
		}
	}

	bpp = 32;

	free( buffer );

	*data = pData;

	return 1;
}


#pragma warning ( default : 4996 )

#endif	// __TGA_H__
