#ifndef __SKINNEDMESH_H__
#define __SKINNEDMESH_H__
#if _MSC_VER > 1000
#	pragma once
#endif	// #if _MSC_VER > 1000

#include "Skeleton.h"
#include "AnimTrack.h"

#include "MathLib/MathLib.h"

#define MAX_WEIGHTS			8
#define MAX_SHADER_WEIGHTS	4

struct VertexWeight
{
	float		weigth;
	int			boneID;
};
struct Vertex
{
	vec3			pos;
	vec3			normal;
	int				numWeights;
	VertexWeight	weights[MAX_WEIGHTS];
};
struct DrawVertex
{
	vec3			pos;
	vec3			normal;		// iOrange- unused right now
	vec4			boneIDs;
	vec4			weights;
	vec2			uv;
};

class SkinnedMesh
{
public:
	SkinnedMesh();
	~SkinnedMesh();

	void ReadFromStream( std::ifstream& stream );
	void BindSkeleton( Skeleton* skeleton );
	void BindAnimTrack( AnimTrack* animTrack );
	void UpdateAnimation( float deltaTime );

	void CreateVBO( void );
	void Draw( int posAttrib, int uvAttrib, int indsAttrib, int weightsAttrib, int bonesArray ) const;

private:
	typedef uint16	INDEX_TYPE;

	void CutLimitWeights( int limit );
	void MoveWeightsToVertexes( void );

	int				m_NumVertexes;
	int				m_NumIndexes;
	Vertex*			m_Vertexes;

	// Draw data
	INDEX_TYPE*		m_Indexes;
	DrawVertex*		m_DrawVertexes;

	Skeleton*		m_Skeleton;
	AnimTrack*		m_AnimTrack;

	Transform*		m_BonesTransform;
	float			m_AnimationTime;

	GLuint			m_VertexBuffer;
	GLuint			m_IndexBuffer;
};

#endif
