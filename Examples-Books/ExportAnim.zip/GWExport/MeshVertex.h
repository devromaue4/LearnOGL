#ifndef __MESHVERTEX_H__
#define __MESHVERTEX_H__

#include <max.h>


class VertexWeight
{
public:

	VertexWeight() : m_Weight(0), m_BoneID(-1) {}
	VertexWeight( float w, int b ) : m_Weight(w), m_BoneID(b) {}

	void SetWeight( float f )
	{
		m_Weight = f;
	}
	void SetBoneID( int i )
	{
		m_BoneID = i;
	}

	float GetWeight( void ) const
	{
		return m_Weight;
	}
	int GetBoneID( void ) const
	{
		return m_BoneID;
	}

	VertexWeight& operator = ( const VertexWeight& other )
	{
		m_Weight = other.m_Weight;
		m_BoneID = other.m_BoneID;
		return (*this);
	}

protected:

	float	m_Weight;
	int		m_BoneID;
};


class MeshVertex
{
public:

	MeshVertex() {}

	MeshVertex( float x, float y, float z )
	{
		m_Pos		= Point3( x, y, z );
		m_Normal	= Point3( 0.0f, 0.0f, 0.0f );
		m_TexCoord	= Point2( 0.0f, 0.0f );
		m_ID		= -1;
	}

	void SetNormal( float x, float y, float z )
	{
		m_Normal = Point3( x, y, z );
	}
	void SetTexCoord( float u, float v )
	{
		m_TexCoord = Point2( u, v );
	}
	void SetID( int id )
	{
		m_ID = id;
	}
	void AddWeight( const VertexWeight& w )
	{
		m_Weights.push_back( w );
	}


	const Point3& GetPosition( void ) const
	{
		return m_Pos;
	}
	const Point3& GetNormal( void ) const
	{
		return m_Normal;
	}
	const Point2& GetTexCoord( void ) const
	{
		return m_TexCoord;
	}
	int GetID( void ) const
	{
		return m_ID;
	}

	const int GetNumWeights( void ) const
	{
		return (int)m_Weights.size();
	}

	const VertexWeight& GetWeight( int i ) const
	{
		return m_Weights[ i ];
	}

	bool operator == ( const MeshVertex& other ) const
	{
		return ( m_Pos == other.m_Pos && m_Normal == other.m_Normal && m_TexCoord == other.m_TexCoord && m_ID == other.m_ID );
	}

	MeshVertex& operator = ( const MeshVertex& other )
	{
		m_Pos		= other.m_Pos;
		m_Normal	= other.m_Normal;
		m_TexCoord	= other.m_TexCoord;
		m_ID		= other.m_ID;
		m_Weights	= other.m_Weights;

		return (*this);
	}

private:

	typedef	std::vector<VertexWeight>	weightsVec;

	Point3			m_Pos;
	Point3			m_Normal;
	Point2			m_TexCoord;
	int				m_ID;
	weightsVec		m_Weights;
};




class MeshVertexList
{
public:

	// iOrange - returns the index into the list for the inserted element
	int Add( const MeshVertex& v )
	{
		int idx = 0;
		vertexVec::const_iterator it;
		for ( it = m_VertexList.begin(); it != m_VertexList.end(); ++it, ++idx )
		{
			if ( *it == v )
				break;
		}

		if ( it == m_VertexList.end() )
			m_VertexList.push_back( v );

		return idx;
	}
	int Count( void ) const
	{
		return (int)m_VertexList.size();
	}
	MeshVertex& operator [] ( int i )
	{
		return m_VertexList[ i ];
	}

	void Clear( void )
	{
		m_VertexList.clear();
	}

private:

	typedef std::vector<MeshVertex>		vertexVec;

	vertexVec		m_VertexList;
};



#endif	// __MESHVERTEX_H__

