//**************************************************************************/
// Copyright (c) 1998-2007 Autodesk, Inc.
// All rights reserved.
// 
// These coded instructions, statements, and computer programs contain
// unpublished proprietary information written by Autodesk, Inc., and are
// protected by Federal copyright law. They may not be disclosed to third
// parties or copied or duplicated in any form, in whole or in part, without
// the prior written consent of Autodesk, Inc.
//**************************************************************************/
// DESCRIPTION: Appwizard generated plugin
//				3DXI file exporter project template
//				For a more in-depth exemple of a 3DXI exporter,
//				please refer to maxsdk\samples\igame\export.
// AUTHOR:		Jean-Francois Yelle - created Mar.20.2007
//***************************************************************************/

#include "GWExport.h"

#include "3dsmaxsdk_preinclude.h"
#include "IGame/IGame.h"

#include "Skeleton.h"
#include "ExportMesh.h"
#include "AnimTrack.h"

#include <sstream>
#include <fstream>


#define GWExport_CLASS_ID	Class_ID(0x9339c6e0, 0x99611b32)

class GWExport : public SceneExport 
{
	public:
		
		virtual int				ExtCount();					// Number of extensions supported
		virtual const TCHAR *	Ext(int n);					// Extension #n (i.e. "3DS")
		virtual const TCHAR *	LongDesc();					// Long ASCII description (i.e. "Autodesk 3D Studio File")
		virtual const TCHAR *	ShortDesc();				// Short ASCII description (i.e. "3D Studio")
		virtual const TCHAR *	AuthorName();				// ASCII Author name
		virtual const TCHAR *	CopyrightMessage();			// ASCII Copyright message
		virtual const TCHAR *	OtherMessage1();			// Other message #1
		virtual const TCHAR *	OtherMessage2();			// Other message #2
		virtual unsigned int	Version();					// Version number * 100 (i.e. v3.01 = 301)
		virtual void			ShowAbout(HWND hWnd);		// Show DLL's "About..." box

		virtual BOOL SupportsOptions(int ext, DWORD options);
		virtual int	DoExport(const TCHAR *name,ExpInterface *ei,Interface *i, BOOL suppressPrompts=FALSE, DWORD options=0);

		//Constructor/Destructor
		GWExport();
		virtual ~GWExport();

	private:
		static HWND hParams;
};



class GWExportClassDesc : public ClassDesc2 
{
public:
	virtual int IsPublic() 							{ return TRUE; }
	virtual void* Create(BOOL /*loading = FALSE*/) 		{ return new GWExport(); }
	virtual const TCHAR *	ClassName() 			{ return GetString(IDS_CLASS_NAME); }
	virtual SClass_ID SuperClassID() 				{ return SCENE_EXPORT_CLASS_ID; }
	virtual Class_ID ClassID() 						{ return GWExport_CLASS_ID; }
	virtual const TCHAR* Category() 				{ return GetString(IDS_CATEGORY); }

	virtual const TCHAR* InternalName() 			{ return _T("GWExport"); }	// returns fixed parsable name (scripter-visible name)
	virtual HINSTANCE HInstance() 					{ return hInstance; }					// returns owning module handle
	

};

static GWExportClassDesc GWExportDesc;
ClassDesc2* GetGWExportDesc() { return &GWExportDesc; }





INT_PTR CALLBACK GWExportOptionsDlgProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM lParam) {
	static GWExport *imp = NULL;

	switch(message) {
		case WM_INITDIALOG:
			imp = (GWExport *)lParam;
			CenterWindow(hWnd,GetParent(hWnd));
			return TRUE;

		case WM_CLOSE:
			EndDialog(hWnd, 0);
			return 1;
	}
	return 0;
}


//--- GWExport -------------------------------------------------------
GWExport::GWExport()
{
}

GWExport::~GWExport() 
{
}

int GWExport::ExtCount()
{
	return 1;
}

const TCHAR *GWExport::Ext(int n)
{
	if ( !n )
		return _T("GWM");
	else
		return _T("");
}

const TCHAR *GWExport::LongDesc()
{
	return _T("GameWorld example skinned mesh");
}
	
const TCHAR *GWExport::ShortDesc() 
{
	return _T("GW Skinned Mesh");
}

const TCHAR *GWExport::AuthorName()
{
	return _T("Sergey \'iOrange\' Kudlay");
}

const TCHAR *GWExport::CopyrightMessage() 
{
	return _T("");
}

const TCHAR *GWExport::OtherMessage1() 
{
	return _T("");
}

const TCHAR *GWExport::OtherMessage2() 
{
	return _T("");
}

unsigned int GWExport::Version()
{
	return 100;
}

void GWExport::ShowAbout(HWND hWnd)
{
	// Optional
}

BOOL GWExport::SupportsOptions(int ext, DWORD options)
{
	// TODO Decide which options to support.  Simply return
	// true for each option supported by each Extension 
	// the exporter supports.

	return TRUE;
}

void WriteBone( std::stringstream& ss, Bone* bone )
{
	ss << bone->GetName() << " " << bone->GetID() << " " << bone->GetParentID() << std::endl;

	// iOrange - write all child bones
	bone = bone->GetChild();
	while ( bone )
	{
		WriteBone( ss, bone );
		bone = bone->GetNext();
	}
}


int	GWExport::DoExport(const TCHAR* name,ExpInterface* ei,Interface* i, BOOL suppressPrompts, DWORD options)
{
	// This is where the file export operation occur.

//	if(!suppressPrompts)
//		DialogBoxParam(hInstance, 
//				MAKEINTRESOURCE(IDD_PANEL), 
//				GetActiveWindow(), 
//				GWExportOptionsDlgProc, (LPARAM)this);

	// Construct a tab with all this scene's nodes.
	// We could also only take the node currently selected, etc.
//	INodeTab lNodes;
//	GetSceneNodes(lNodes);

	int exportResult = FALSE;
	std::stringstream ss;
	std::ofstream os;


	// Initialise 3DXI (formerly IGame) object
	// For more information, please see 3ds Max SDK topic PG: Programming with 3DXI.
	IGameScene * pIgame = GetIGameInterface();

	// iOrange - must do this before any data initializations!
	IGameConversionManager* cm = GetConversionManager();
	cm->SetCoordSystem( IGameConversionManager::IGAME_OGL );

	//pIgame->InitialiseIGame(lNodes);
	pIgame->InitialiseIGame();
	pIgame->SetStaticFrame(0);

	Tab<IGameNode*> meshes = pIgame->GetIGameNodeByType( IGameObject::IGAME_MESH );
	if ( meshes.Count() == 0 )
		return FALSE;

	IGameNode* node = meshes[0];
	IGameObject* obj = node->GetIGameObject();
	obj->InitializeData();


	Skeleton	skeleton;
	ExportMesh	expMesh;
	AnimTrack	animTrack;

	// iOrange - capture bones and build hierarhy
	if ( !skeleton.Build( obj ) )
		goto export_ends_here;
	// iOrange - capture mesh data
	if ( expMesh.Build( obj, node ) != ExportMesh::RET_OK )
		goto export_ends_here;
	// iOrange - capture per-vertex bones influence
	if ( !expMesh.CaptureVertexWeights( obj, &skeleton ) )
		goto export_ends_here;
	// iOrange - capture bones transformation on each frame
	if ( !animTrack.Build( obj, &skeleton ) )
		goto export_ends_here;


	skeleton.WriteToStream( ss );
	expMesh.WriteToStream( ss );
	animTrack.WriteToStream( ss );

	os.open( name, std::ios::out );
	os << ss.str();
	os.flush();
	os.close();

	exportResult = TRUE;


export_ends_here:

	node->ReleaseIGameObject();
	pIgame->ReleaseIGame();

	return exportResult;
}

