#include "stdafx.h"



SkinnedMesh::SkinnedMesh()
	: m_NumVertexes(0)
	, m_NumIndexes(0)
	, m_Vertexes(NULL)
	, m_Indexes(NULL)
	, m_DrawVertexes(NULL)
	, m_BonesTransform(NULL)
	, m_AnimationTime(0.0f)
	, m_VertexBuffer(0)
	, m_IndexBuffer(0)
{}
SkinnedMesh::~SkinnedMesh()
{
	if ( m_Vertexes )
		delete [] m_Vertexes;
	if ( m_Indexes )
		delete [] m_Indexes;
	if ( m_DrawVertexes )
		delete [] m_DrawVertexes;
	if ( m_BonesTransform )
		delete [] m_BonesTransform;
}



void SkinnedMesh::ReadFromStream( std::ifstream& stream )
{
	int i, j;

	stream >> m_NumVertexes >> m_NumIndexes;

	m_Vertexes = new Vertex[m_NumVertexes];
	m_Indexes = new INDEX_TYPE[m_NumIndexes];
	m_DrawVertexes = new DrawVertex[m_NumVertexes];

	// iOrange - reading vertexes
	Vertex* v = m_Vertexes;
	DrawVertex* dv = m_DrawVertexes;
	for ( i = 0; i < m_NumVertexes; ++i, ++v, ++dv )
	{
		stream >> v->pos.x >> v->pos.y >> v->pos.z;				// position
		stream >> v->normal.x >> v->normal.y >> v->normal.z;	// normal
		stream >> dv->uv.x >> dv->uv.y;							// texCoord
		stream >> v->numWeights;								// num weights
		for ( j = 0; j < v->numWeights; ++j )
			stream >> v->weights[j].boneID >> v->weights[j].weigth;
	}

	// iOrange - reading indexes
	INDEX_TYPE* p = m_Indexes;
	for ( i = 0; i < m_NumIndexes; ++i )
		stream >> *p++;

	this->CreateVBO();
}

void SkinnedMesh::BindSkeleton( Skeleton* skeleton )
{
	if ( NULL != (m_Skeleton = skeleton) )
	{
		if ( m_BonesTransform )
			delete [] m_BonesTransform;
		m_BonesTransform = new mat4[m_Skeleton->GetNumBones()];

		Bone* bone;
		for ( int i = 0; i < m_Skeleton->GetNumBones(); ++i )
		{
			if ( bone = m_Skeleton->GetBoneByID( i ) )
				bone->SetTransform( m_BonesTransform + i );
		}
	}
}

void SkinnedMesh::BindAnimTrack( AnimTrack* animTrack )
{
	if ( !m_Skeleton || !animTrack )
		return;

	m_AnimTrack = animTrack;

	// iOrange - setup first frame up!
	this->UpdateAnimation( 0 );
	m_Skeleton->SetupBindPose();
}

void SkinnedMesh::UpdateAnimation( float deltaTime )
{
	if ( !m_Skeleton || !m_AnimTrack )
		return;

	const float fps  = 10.0f;

	m_AnimationTime += deltaTime;

	// =[ 0r@ngE ]= - calculating 2 current frames and lerp time between them
	float st        = m_AnimationTime * fps;
	int   ist       = (int)floorf( st );
	int   f0        = ist % m_AnimTrack->GetNumFrames();
	int   f1        = ( f0 + 1 ) % m_AnimTrack->GetNumFrames();
	float frameLerp = st - float( ist );
	int   i, j;

	AnimFrame* frame0 = m_AnimTrack->GetAnimFrame( f0 );
	AnimFrame* frame1 = m_AnimTrack->GetAnimFrame( f1 );

	for ( i = 0; i < m_Skeleton->GetNumBones(); ++i )
	{
		vec3 offset = lerp( frame0->GetOffset( i ), frame1->GetOffset( i ), frameLerp );
		quat rotation = slerp( frame0->GetRotation( i ), frame1->GetRotation( i ), frameLerp );

		m_BonesTransform[i] = Quat2Mat4( rotation );
		m_BonesTransform[i].SetTranslateVector( offset );
	}

	m_Skeleton->AnimateHierarhy();

	Vertex* v = m_Vertexes;
	DrawVertex* dv = m_DrawVertexes;
	for ( i = 0; i < m_NumVertexes; ++i, ++v, ++dv )
	{
		for ( j = 0; j < v->numWeights; ++j )
		{
			mat4* boneTransform = &m_BonesTransform[v->weights[j].boneID];
			float w = v->weights[j].weigth;

			if ( !j )
			{
				dv->pos = boneTransform->TransformPoint( v->pos ) * w;
				dv->normal = boneTransform->TransformDirection( v->normal ) * w;
			}
			else
			{
				dv->pos += boneTransform->TransformPoint( v->pos ) * w;
				dv->normal += boneTransform->TransformDirection( v->normal ) * w;
			}
		}
	}

	glext::glBindBufferARB( GL_ARRAY_BUFFER, m_VertexBuffer );
	glext::glBufferSubDataARB( GL_ARRAY_BUFFER, 0, m_NumVertexes * sizeof(DrawVertex), m_DrawVertexes );
}

void SkinnedMesh::CreateVBO( void )
{
	glext::glGenBuffersARB( 1, &m_VertexBuffer );
	glext::glGenBuffersARB( 1, &m_IndexBuffer );

	glext::glBindBufferARB( GL_ARRAY_BUFFER, m_VertexBuffer );
	glext::glBufferDataARB( GL_ARRAY_BUFFER, m_NumVertexes * sizeof(DrawVertex), NULL, GL_STREAM_DRAW );

	glext::glBindBufferARB( GL_ELEMENT_ARRAY_BUFFER, m_IndexBuffer );
	glext::glBufferDataARB( GL_ELEMENT_ARRAY_BUFFER, m_NumIndexes * sizeof(INDEX_TYPE), m_Indexes, GL_STATIC_DRAW );

	glext::glBindBufferARB( GL_ARRAY_BUFFER, 0 );
	glext::glBindBufferARB( GL_ELEMENT_ARRAY_BUFFER, 0 );
}

void SkinnedMesh::Draw( int posAttrib, int uvAttrib )
{
	glext::glBindBufferARB( GL_ARRAY_BUFFER, m_VertexBuffer );
	glext::glBindBufferARB( GL_ELEMENT_ARRAY_BUFFER, m_IndexBuffer );

	glext::glEnableVertexAttribArrayARB( posAttrib );
	glext::glEnableVertexAttribArrayARB( uvAttrib );

	glext::glVertexAttribPointerARB( posAttrib, 3, GL_FLOAT, GL_FALSE, sizeof(DrawVertex), NULL );
	glext::glVertexAttribPointerARB( uvAttrib, 2, GL_FLOAT, GL_FALSE, sizeof(DrawVertex), vbo_offsetof(DrawVertex, uv) );

	glDrawElements( GL_TRIANGLES, m_NumIndexes,
					sizeof(INDEX_TYPE) == 2 ? GL_UNSIGNED_SHORT : GL_UNSIGNED_INT,
					NULL );
}

