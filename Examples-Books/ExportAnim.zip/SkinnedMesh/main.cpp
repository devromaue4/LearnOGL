#include "stdafx.h"

#include <fstream>
#include <strstream>

#include "Skeleton.h"
#include "AnimTrack.h"
#include "SkinnedMesh.h"


HWND		g_hWnd;
HINSTANCE	g_hInst;

const char * _className = "Orange_Class_Wnd";
const char * _windowName = "OpenGL 3.0";

const int _WND_WIDTH	=	800;
const int _WND_HEIGHT	=	600;

template<int what, int to>
int change_char( int c ) { if ( what == c ) return to; return c; }

LRESULT CALLBACK WndProc( HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam );
bool CreateMainWindow( int w, int h );
void LoadTexture( const char* texName );
void Draw( void );


GLint		_modelViewProjection;
GLint		_vertPosition;
GLint		_vertUV;
GLuint		_texture;

uint32 _prevTime;
mat4   proj, mv, mvp;


Skeleton		skelet;
AnimTrack		animTrack;
SkinnedMesh		skinnedMesh;


int main( int argc, char* argv[] )
{
	g_hInst = GetModuleHandle( NULL );

	Log_Normal( "Creating main window..." );
	if ( !CreateMainWindow( _WND_WIDTH, _WND_HEIGHT ) )
	{
		Log_Error( "Couldn't create main window" );
		return 1;
	}

	HGLRC _glRC;
	Log_Normal( "Trying to initialize OpenGL 3.0" );
	if ( !OpenGL_3::Initialize( g_hWnd, _glRC ) )
	{
		Log_Error( "Couldn't init OpenGL 3.0... Shutdown..." );
		return 1;
	}
	OpenGL_3::AssertGLError();

	std::string oglversion = OpenGL_3::GetVersion();
	OpenGL_3::AssertGLError();
	std::string ogl_vendor = OpenGL_3::GetVendor();
	OpenGL_3::AssertGLError();
	std::string ogl_renderer = OpenGL_3::GetRenderer();
	OpenGL_3::AssertGLError();
	std::string extensions = OpenGL_3::GetExtensions();
	OpenGL_3::AssertGLError();
	std::string wgl_extens = OpenGL_3::GetWGLExtensions();
	OpenGL_3::AssertGLError();
	std::transform( extensions.begin(), extensions.end(), extensions.begin(), change_char<' ','\n'> );
	std::transform( wgl_extens.begin(), wgl_extens.end(), wgl_extens.begin(), change_char<' ','\n'> );
	std::cout << "OpenGL Version  :  " << oglversion << std::endl;
	std::cout << "OpenGL Vendor   :  " << ogl_vendor << std::endl;
	std::cout << "OpenGL Renderer :  " << ogl_renderer << std::endl;
	std::cout << "OpenGL Extentions:" << std::endl << extensions << std::endl;
	std::cout << "OpenGL WGL-Extentions:" << std::endl << wgl_extens << std::endl;

	Log_Normal( "Initializing Multi-textures extensions..." );
	if ( !glext::InitMultitextureExtensions() )
	{
		Log_Error( "Couldn't initialize Multi-textures extensions" );
		OpenGL_3::Shutdown();
	}
	Log_Normal( "Initializing VBO extensions..." );
	if ( !glext::InitVBO() )
	{
		Log_Error( "Couldn't initialize VBO" );
		OpenGL_3::Shutdown();
	}
	Log_Normal( "Initializing VBO extensions OK" );
	glext::InitVertexAttribs();
	Log_Normal( "Initializing GLSL extensions..." );
	if ( !glext::InitGLSLNeededExts() )
	{
		Log_Error( "Couldn't initialize GLSL" );
		OpenGL_3::Shutdown();
	}
	Log_Normal( "Initializing GLSL extensions OK" );
	std::cout << "OpenGL GLSL Version :  " << OpenGL_3::GetGLSLVersion() << std::endl;

	const std::string vs =	"#version 130\n"\
							"\tprecision highp float;\n"\
							"\tuniform mat4x4 modelViewProjection;\n"\
							"\tin vec4 vPos;\n"\
							"\tin vec2 vTexCoord;\n"\
							"\tout vec2 tc;\n"\
							"\tvoid main() {\n"\
							"\t\ttc = vTexCoord;\n"\
							"\t\tgl_Position = modelViewProjection * vPos;\n"\
							"\t}\n";
	const std::string fs =	"#version 130\n"\
							"\tprecision highp float;\n"\
							"\tuniform sampler2D diffuse;\n"\
							"\tin vec2 tc;\n"\
							"\tout vec4 fragColor;\n"\
							"\tvoid main() {\n"\
							"\tfragColor = texture(diffuse, tc);\n"\
							"\t}\n";

	Log_Normal( "Try to compile such shader:\nVertex Program:\n\t" + vs + "Fragment Program:\n\t" + fs );
	GLhandleARB program = OpenGL_3::CreateGLSLProgram( vs, fs );
	if ( NULL == program )
	{
		Log_Error( "Compilation failed... Exiting..." );
		exit( 1 );
	}
	Log_Normal( "Compilation ok!" );

	glext::glUseProgramObjectARB( program );
	_modelViewProjection = glext::glGetUniformLocationARB( program, "modelViewProjection" );
	_vertPosition = glext::glGetAttribLocationARB( program, "vPos" );
	_vertUV = glext::glGetAttribLocationARB( program, "vTexCoord" );
	// iOrange - set the texture unit
	glext::glUniform1iARB( glext::glGetUniformLocationARB( program, "diffuse" ), 0 );

	glViewport( 0, 0, _WND_WIDTH, _WND_HEIGHT );
	glScissor( 0, 0, _WND_WIDTH, _WND_HEIGHT );
	glClearColor( 0, 0, 0, 1 );
	glClearDepth( 1.0f );
	glEnable( GL_DEPTH_TEST );
	glDepthFunc( GL_LEQUAL );

	proj = MakePerspective( 60, float(_WND_WIDTH)/float(_WND_HEIGHT), 0.1f, 1000 );
	mv = MakeLookAt( vec3(-50, 100, -90), vec3(0, 0, 0), vec3(0, 1, 0) );
	mvp = proj * mv;

	glext::glUniformMatrix4fvARB( _modelViewProjection, 1, 0, mvp );

	OpenGL_3::AssertGLError();

	std::ifstream	stream;
	stream.open( "data\\arab.gwm", std::ios::in );

	skelet.ReadFromStream( stream );
	skinnedMesh.ReadFromStream( stream );
	animTrack.ReadFromStream( stream, skelet.GetNumBones() );

	stream.close();

	LoadTexture( "data\\arab.tga" );

	OpenGL_3::AssertGLError();

	skinnedMesh.BindSkeleton( &skelet );
	skinnedMesh.BindAnimTrack( &animTrack );

	OpenGL_3::AssertGLError();

	_prevTime = GetTickCount();
	
	MSG msg;
	while ( true )
	{
		if ( PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ) )
		{
			if ( !GetMessage( &msg, NULL, 0, 0 ) || WM_QUIT == msg.message )
				break;
			else
			{
				TranslateMessage( &msg );
				DispatchMessage ( &msg );
			}
		}

		Draw();
		Sleep(1);
	}

	OpenGL_3::Shutdown();
	return 0;
}

LRESULT CALLBACK WndProc( HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam )
{
	switch ( wMsg )
	{
		case WM_KEYDOWN:
		{
			if ( VK_ESCAPE == wParam )
				PostQuitMessage(0);
		} return 0;

		case WM_DESTROY:
		case WM_CLOSE:
		{
			PostQuitMessage(0);
		} return 0;

		default:
			return DefWindowProc( hWnd, wMsg, wParam, lParam );
	}
}

bool CreateMainWindow( int w, int h )
{
	WNDCLASSEX wc;
	RtlZeroMemory( &wc, sizeof( wc ) );
	wc.cbSize        = sizeof( wc );
	wc.style         = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wc.lpfnWndProc   = (WNDPROC)WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = GetModuleHandle( NULL );
	wc.hIcon         = LoadIcon( NULL, IDI_WINLOGO );
	wc.hCursor       = LoadCursor( NULL, IDC_ARROW );
	wc.hbrBackground = NULL;
	wc.lpszMenuName  = NULL;
	wc.lpszClassName = _className;

	if ( !RegisterClassEx( &wc ) )
	{
		Log_Error( "Couldn't register wnd class" );
		return false;
	}
	uint32 styleEx = 0;
	uint32 style   = (WS_VISIBLE | WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS | WS_CLIPCHILDREN) ^ WS_MAXIMIZEBOX;
	RECT rc;
	SetRect( &rc, 0, 0, w, h );
	AdjustWindowRectEx( &rc, style, FALSE, styleEx );
	if ( !( g_hWnd = CreateWindowEx( styleEx, _className, _windowName, style, 0, 0,
									 rc.right - rc.left, rc.bottom - rc.top, 0, 0, g_hInst, 0 ) ) )
	{
		Log_Error( "Couldn't create main window" );
		UnregisterClass( _className, g_hInst );
		return false;
	}

	return true;
}

void LoadTexture( const char* texName )
{
	int w, h, bpp;
	uint8* data = NULL;

	if ( !LoadTGAFile( texName, w, h, bpp, &data ) )
		return;

	glGenTextures( 1, &_texture );

	glBindTexture( GL_TEXTURE_2D, _texture );

	glTexParameteri	( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
	glTexParameteri	( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
	glTexParameteri	( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri	( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glPixelStorei	( GL_UNPACK_ALIGNMENT, 1 );

	glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data );

	glBindTexture( GL_TEXTURE_2D, 0 );

	free( data );
}

void Draw( void )
{
	glClear( GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT );

	uint32 deltaTime = GetTickCount() - _prevTime;
	_prevTime = GetTickCount();

	glext::glActiveTextureARB( GL_TEXTURE0 );
	glBindTexture( GL_TEXTURE_2D, _texture );

	skinnedMesh.UpdateAnimation( static_cast<float>(deltaTime) / 1000.0f );
	skinnedMesh.Draw( _vertPosition, _vertUV );

	glBindTexture( GL_TEXTURE_2D, 0 );

	SwapBuffers( wglGetCurrentDC() );
}
