#ifndef __ANIMTRACK_H__
#define __ANIMTRACK_H__
#if _MSC_VER > 1000
#	pragma once
#endif	// #if _MSC_VER > 1000

#include <vector>
#include <fstream>

#include "MathLib/MathLib.h"

class AnimFrame
{
public:
	AnimFrame( int numBones )
		: m_NumBones(numBones)
	{
		m_Rotations.reserve( numBones );
		m_Offsets.reserve( numBones );
	}

	void ReadFromStream( std::ifstream& stream )
	{
		int i;
		float x, y, z ,w;

		for ( i = 0; i < m_NumBones; ++i )
		{
			// iOrange - reading offset vec3
			stream >> x >> y >> z;
			m_Offsets.push_back( vec3( x, y, z ) );
			// iOrange - reading rotation quat
			stream >> x >> y >> z >> w;
			m_Rotations.push_back( quat( x, y, z, w ) );
		}
	}

	const quat& GetRotation( int i ) const
	{
		return m_Rotations[i];
	}
	const vec3& GetOffset( int i ) const
	{
		return m_Offsets[i];
	}


private:
	typedef std::vector<quat>	quatsVec;
	typedef std::vector<vec3>	vecsVec;

	int				m_NumBones;
	quatsVec		m_Rotations;
	vecsVec			m_Offsets;

};


class AnimTrack
{
public:
	AnimTrack()
	{}
	~AnimTrack()
	{
		for ( framesVec::iterator it = m_Frames.begin(); it != m_Frames.end(); ++it )
			delete (*it);
	}

	void ReadFromStream( std::ifstream& stream, int numBones )
	{
		int i, numFrames = 0;

		stream >> numFrames;
		m_Frames.reserve( numFrames );

		for ( i = 0; i < numFrames; ++i )
		{
			AnimFrame* frame = new AnimFrame( numBones );
			frame->ReadFromStream( stream );
			m_Frames.push_back( frame );
		}
	}

	int GetNumFrames( void ) const
	{
		return (int)m_Frames.size();
	}
	AnimFrame* GetAnimFrame( int i ) const
	{
		return m_Frames[i];
	}

private:
	typedef std::vector<AnimFrame*>		framesVec;

	framesVec		m_Frames;
};

#endif

