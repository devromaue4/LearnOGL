#ifndef __OGLEXTENSIONS_H__
#define __OGLEXTENSIONS_H__
#if _MSC_VER > 1000
#	pragma once
#endif	// _MSC_VER > 1000

namespace glext
{

// WindoZe ����������
extern  PFNWGLGETEXTENSIONSSTRINGEXTPROC                wglGetExtensionsStringEXT;
extern	PFNWGLGETEXTENSIONSSTRINGARBPROC				wglGetExtensionsStringARB;

// WGL_ARB_pixel_format
extern  PFNWGLGETPIXELFORMATATTRIBIVARBPROC				wglGetPixelFormatAttribivARB;
extern  PFNWGLGETPIXELFORMATATTRIBFVARBPROC				wglGetPixelFormatAttribfvARB;
extern  PFNWGLCHOOSEPIXELFORMATARBPROC					wglChoosePixelFormatARB;

// VSync									   
extern  PFNWGLSWAPINTERVALEXTPROC                       wglSwapIntervalEXT;
extern  PFNWGLGETSWAPINTERVALEXTPROC                    wglGetSwapIntervalEXT;
											   
// ARB ����� � �������						   
extern  PFNGLPOINTPARAMETERFARBPROC                     glPointParameterfARB;
extern  PFNGLPOINTPARAMETERFVARBPROC                    glPointParameterfvARB;
											   
// �������������							   
extern	PFNGLACTIVETEXTUREARBPROC                       glActiveTextureARB;
extern	PFNGLCLIENTACTIVETEXTUREARBPROC                 glClientActiveTextureARB;
extern	PFNGLMULTITEXCOORD1FARBPROC                     glMultiTexCoord1f;
extern	PFNGLMULTITEXCOORD1FVARBPROC                    glMultiTexCoord1fv;
extern	PFNGLMULTITEXCOORD2FARBPROC                     glMultiTexCoord2f;
extern	PFNGLMULTITEXCOORD2FVARBPROC                    glMultiTexCoord2fv;
extern	PFNGLMULTITEXCOORD3FARBPROC                     glMultiTexCoord3f;
extern	PFNGLMULTITEXCOORD3FVARBPROC                    glMultiTexCoord3fv;
extern	PFNGLMULTITEXCOORD4FARBPROC                     glMultiTexCoord4f;
extern	PFNGLMULTITEXCOORD4FVARBPROC                    glMultiTexCoord4fv;
											   
// ���������� ��������						   
extern	PFNGLTEXIMAGE3DEXTPROC                          glTexImage3DEXT;
extern	PFNGLTEXSUBIMAGE3DEXTPROC                       glTexSubImage3DEXT;
extern	PFNGLCOPYTEXSUBIMAGE3DEXTPROC                   glCopyTexSubImage3DEXT;

// ������ ��������
extern	PFNGLCOMPRESSEDTEXIMAGE1DARBPROC                glCompressedTexImage1DARB;
extern	PFNGLCOMPRESSEDTEXIMAGE2DARBPROC                glCompressedTexImage2DARB;
extern	PFNGLCOMPRESSEDTEXIMAGE3DARBPROC                glCompressedTexImage3DARB;
extern	PFNGLCOMPRESSEDTEXSUBIMAGE1DARBPROC             glCompressedTexSubImage1DARB;
extern	PFNGLCOMPRESSEDTEXSUBIMAGE2DARBPROC             glCompressedTexSubImage2DARB;
extern	PFNGLCOMPRESSEDTEXSUBIMAGE3DARBPROC             glCompressedTexSubImage3DARB;
extern	PFNGLGETCOMPRESSEDTEXIMAGEARBPROC               glGetCompressedTexImageARB;

// glDrawRangeElementsEXT
extern	PFNGLDRAWRANGEELEMENTSPROC                      glDrawRangeElementsEXT;

// ���������� �������
extern  PFNGLBINDBUFFERARBPROC                          glBindBufferARB;
extern  PFNGLDELETEBUFFERSARBPROC                       glDeleteBuffersARB;
extern  PFNGLGENBUFFERSARBPROC                          glGenBuffersARB;
extern  PFNGLISBUFFERARBPROC                            glIsBufferARB;
extern  PFNGLBUFFERDATAARBPROC                          glBufferDataARB;
extern  PFNGLBUFFERSUBDATAARBPROC                       glBufferSubDataARB;
extern  PFNGLGETBUFFERSUBDATAARBPROC                    glGetBufferSubDataARB;
extern  PFNGLMAPBUFFERARBPROC                           glMapBufferARB;
extern  PFNGLUNMAPBUFFERARBPROC                         glUnmapBufferARB;
extern  PFNGLGETBUFFERPARAMETERIVARBPROC                glGetBufferParameterivARB;
extern  PFNGLGETBUFFERPOINTERVARBPROC                   glGetBufferPointervARB;

// ��� ASM-��������
extern	PFNGLGENPROGRAMSARBPROC                         glGenProgramsARB;
extern	PFNGLDELETEPROGRAMSARBPROC                      glDeleteProgramsARB;
extern	PFNGLBINDPROGRAMARBPROC                         glBindProgramARB;
extern	PFNGLISPROGRAMARBPROC                           glIsProgramARB;
extern	PFNGLPROGRAMSTRINGARBPROC                       glProgramStringARB;
extern	PFNGLGETPROGRAMIVARBPROC                        glGetProgramivARB;
extern	PFNGLVERTEXATTRIB4FARBPROC                      glVertexAttrib4fARB;
extern	PFNGLVERTEXATTRIB4FVARBPROC                     glVertexAttrib4fvARB;
extern	PFNGLVERTEXATTRIB3FARBPROC                      glVertexAttrib3fARB;
extern	PFNGLVERTEXATTRIB3FVARBPROC                     glVertexAttrib3fvARB;
extern	PFNGLVERTEXATTRIBPOINTERARBPROC                 glVertexAttribPointerARB;
extern	PFNGLENABLEVERTEXATTRIBARRAYARBPROC             glEnableVertexAttribArrayARB;
extern	PFNGLDISABLEVERTEXATTRIBARRAYARBPROC            glDisableVertexAttribArrayARB;
extern	PFNGLPROGRAMLOCALPARAMETER4FARBPROC             glProgramLocalParameter4fARB;
extern	PFNGLPROGRAMLOCALPARAMETER4FVARBPROC            glProgramLocalParameter4fvARB;
extern	PFNGLGETPROGRAMLOCALPARAMETERFVARBPROC          glGetProgramLocalParameterfvARB;
extern	PFNGLPROGRAMENVPARAMETER4FARBPROC               glProgramEnvParameter4fARB;
extern	PFNGLPROGRAMENVPARAMETER4FVARBPROC              glProgramEnvParameter4fvARB;
extern	PFNGLGETPROGRAMENVPARAMETERFVARBPROC            glGetProgramEnvParameterfvARB;

// ��� PBuffer'��
extern  PFNWGLCREATEPBUFFERARBPROC                      wglCreatePbufferARB;
extern  PFNWGLGETPBUFFERDCARBPROC                       wglGetPbufferDCARB;
extern  PFNWGLRELEASEPBUFFERDCARBPROC                   wglReleasePbufferDCARB;
extern  PFNWGLDESTROYPBUFFERARBPROC                     wglDestroyPbufferARB;
extern  PFNWGLQUERYPBUFFERARBPROC                       wglQueryPbufferARB;
//extern  PFNWGLCHOOSEPIXELFORMATARBPROC                  wglChoosePixelFormatARB;
extern  PFNWGLBINDTEXIMAGEARBPROC                       wglBindTexImageARB;
extern  PFNWGLRELEASETEXIMAGEARBPROC                    wglReleaseTexImageARB;
extern  PFNWGLSETPBUFFERATTRIBARBPROC                   wglSetPbufferAttribARB;

// ��� GLSL-��������
extern  PFNGLDELETEOBJECTARBPROC                        glDeleteObjectARB;
extern  PFNGLGETHANDLEARBPROC                           glGetHandleARB;
extern  PFNGLDETACHOBJECTARBPROC                        glDetachObjectARB;
extern  PFNGLCREATESHADEROBJECTARBPROC                  glCreateShaderObjectARB;
extern  PFNGLSHADERSOURCEARBPROC                        glShaderSourceARB;
extern  PFNGLCOMPILESHADERARBPROC                       glCompileShaderARB;
extern  PFNGLCREATEPROGRAMOBJECTARBPROC                 glCreateProgramObjectARB;
extern  PFNGLATTACHOBJECTARBPROC                        glAttachObjectARB;
extern  PFNGLLINKPROGRAMARBPROC                         glLinkProgramARB;
extern  PFNGLUSEPROGRAMOBJECTARBPROC                    glUseProgramObjectARB;
extern  PFNGLVALIDATEPROGRAMARBPROC                     glValidateProgramARB;
extern  PFNGLUNIFORM1FARBPROC                           glUniform1fARB;
extern  PFNGLUNIFORM2FARBPROC                           glUniform2fARB;
extern  PFNGLUNIFORM3FARBPROC                           glUniform3fARB;
extern  PFNGLUNIFORM4FARBPROC                           glUniform4fARB;
extern  PFNGLUNIFORM1IARBPROC                           glUniform1iARB;
extern  PFNGLUNIFORM2IARBPROC                           glUniform2iARB;
extern  PFNGLUNIFORM3IARBPROC                           glUniform3iARB;
extern  PFNGLUNIFORM4IARBPROC                           glUniform4iARB;
extern  PFNGLUNIFORM1FVARBPROC                          glUniform1fvARB;
extern  PFNGLUNIFORM2FVARBPROC                          glUniform2fvARB;
extern  PFNGLUNIFORM3FVARBPROC                          glUniform3fvARB;
extern  PFNGLUNIFORM4FVARBPROC                          glUniform4fvARB;
extern  PFNGLUNIFORM1IVARBPROC                          glUniform1ivARB;
extern  PFNGLUNIFORM2IVARBPROC                          glUniform2ivARB;
extern  PFNGLUNIFORM3IVARBPROC                          glUniform3ivARB;
extern  PFNGLUNIFORM4IVARBPROC                          glUniform4ivARB;
extern  PFNGLUNIFORMMATRIX2FVARBPROC                    glUniformMatrix2fvARB;
extern  PFNGLUNIFORMMATRIX3FVARBPROC                    glUniformMatrix3fvARB;
extern  PFNGLUNIFORMMATRIX4FVARBPROC                    glUniformMatrix4fvARB;
extern  PFNGLGETOBJECTPARAMETERFVARBPROC                glGetObjectParameterfvARB;
extern  PFNGLGETOBJECTPARAMETERIVARBPROC                glGetObjectParameterivARB;
extern  PFNGLGETINFOLOGARBPROC                          glGetInfoLogARB;
extern  PFNGLGETATTACHEDOBJECTSARBPROC                  glGetAttachedObjectsARB;
extern  PFNGLGETUNIFORMLOCATIONARBPROC                  glGetUniformLocationARB;
extern  PFNGLGETACTIVEUNIFORMARBPROC                    glGetActiveUniformARB;
extern  PFNGLGETUNIFORMFVARBPROC                        glGetUniformfvARB;
extern  PFNGLGETUNIFORMIVARBPROC                        glGetUniformivARB;
extern  PFNGLGETSHADERSOURCEARBPROC                     glGetShaderSourceARB;
extern  PFNGLBINDATTRIBLOCATIONARBPROC                  glBindAttribLocationARB;
extern  PFNGLGETACTIVEATTRIBARBPROC                     glGetActiveAttribARB;
extern  PFNGLGETATTRIBLOCATIONARBPROC                   glGetAttribLocationARB;
extern  PFNGLGETVERTEXATTRIBFVARBPROC                   glGetVertexAttribfvARB;

// ��� RTT ( FBO )
extern  PFNGLISRENDERBUFFEREXTPROC                      glIsRenderbufferEXT;
extern  PFNGLBINDRENDERBUFFEREXTPROC                    glBindRenderbufferEXT;
extern  PFNGLDELETERENDERBUFFERSEXTPROC                 glDeleteRenderbuffersEXT;
extern  PFNGLGENRENDERBUFFERSEXTPROC                    glGenRenderbuffersEXT;
extern  PFNGLRENDERBUFFERSTORAGEEXTPROC                 glRenderbufferStorageEXT;
extern  PFNGLGETRENDERBUFFERPARAMETERIVEXTPROC          glGetRenderbufferParameterivEXT;
extern  PFNGLISFRAMEBUFFEREXTPROC                       glIsFramebufferEXT;
extern  PFNGLBINDFRAMEBUFFEREXTPROC                     glBindFramebufferEXT;
extern  PFNGLDELETEFRAMEBUFFERSEXTPROC                  glDeleteFramebuffersEXT;
extern  PFNGLGENFRAMEBUFFERSEXTPROC                     glGenFramebuffersEXT;
extern  PFNGLCHECKFRAMEBUFFERSTATUSEXTPROC              glCheckFramebufferStatusEXT;
extern  PFNGLFRAMEBUFFERTEXTURE1DEXTPROC                glFramebufferTexture1DEXT;
extern  PFNGLFRAMEBUFFERTEXTURE2DEXTPROC                glFramebufferTexture2DEXT;
extern  PFNGLFRAMEBUFFERTEXTURE3DEXTPROC                glFramebufferTexture3DEXT;
extern  PFNGLFRAMEBUFFERRENDERBUFFEREXTPROC             glFramebufferRenderbufferEXT;
extern  PFNGLGETFRAMEBUFFERATTACHMENTPARAMETERIVEXTPROC glGetFramebufferAttachmentParameterivEXT;
extern  PFNGLGENERATEMIPMAPEXTPROC                      glGenerateMipmapEXT;

// ��� ���������� blend-factors �� RGB � ALPHA
extern  PFNGLBLENDFUNCSEPARATEPROC						glBlendFuncSeparateEXT;
extern  PFNGLBLENDEQUATIONSEPARATEEXTPROC				glBlendEquationSeparateEXT;
extern  PFNGLBLENDEQUATIONEXTPROC						glBlendEquationEXT;

// ������������� WGL_ARB_pixel_format
bool InitARB_pixel_format( void );
// ������������� ���������� ��� ��������������
bool InitMultitextureExtensions( void );
// ������������� 3D �������
bool Init3DTextures( void );
// ������������� ������ ��������
bool InitCompressedTextures( void );
// glDrawRangeElements
bool Init_glDrawRangeElements( void );
// ������������� ���������� ��������
bool InitVBO( void );
// ������������� ���������� ��� GLSL
bool InitGLSLNeededExts( void );
// ������������� ���������� ��� Vertex Attribs
bool InitVertexAttribs( void );
// ������������� ���������� ��� VSync
bool InitVSync( void );
// ������������� ���������� ��� FBO
bool InitFBO( void );
// ������������� ���������� ��� ���������� blend-factors �� RGB � ALPHA
bool InitBlendFuncSeparate( void );

}; // namespace glext

#endif // __OGLEXTENSIONS_H__
